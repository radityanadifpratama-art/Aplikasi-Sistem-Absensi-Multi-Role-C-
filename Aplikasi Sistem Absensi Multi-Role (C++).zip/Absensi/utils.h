#pragma once
#include <string>
#include <thread>
#include <chrono>
using namespace std;

// Warna Terminal (ANSI CODES)
const string RESET = "\033[0m";
const string BOLD = "\033[1m";
const string RED = "\033[31m";
const string BOLD_RED = "\033[1;31m";
const string GREEN = "\033[32m";
const string BOLD_GREEN = "\033[1;32m";
const string YELLOW = "\033[33m";
const string BOLD_YELLOW = "\033[1;33m";
const string BLUE = "\033[34m";
const string BOLD_BLUE = "\033[1;34m";
const string CYAN = "\033[36m";
const string BOLD_CYAN = "\033[1;36m";
const string MAGENTA = "\033[35m";
const string BOLD_MAGENTA = "\033[1;35m";

void clearScreen();
void delayMilliseconds(int milliseconds);
int promptInt(const string& prompt);
string promptValidated(const string& prompt, size_t maxLen, bool required = true);
string promptNameValidated(const string& prompt, size_t maxLen, bool required = true);
string promptDigitsValidated(const string& prompt, size_t maxLen, bool required = true);
string promptDateValidated(const string& prompt);
string promptWeekValidated(const string& prompt);
string promptStudentIdValidated(const string& prompt);
string promptFileNameValidated(const string& prompt, size_t maxLen);

int dateToAbsoluteDays(const string& dateStr);
string promptPasswordValidated(const string& prompt, size_t maxLen, bool required = true);
string hashPassword(const string& password);