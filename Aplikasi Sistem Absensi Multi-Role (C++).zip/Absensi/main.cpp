#include <iostream>

#include "attendance_manager.h"
#include "auth_manager.h"
#include "utils.h"
using namespace std;

int main() {
  #ifdef _WIN32
    system("chcp 65001 > nul"); // Memaksa CMD Windows menggunakan UTF-8
  #endif
  
  AuthManager authSystem;
  AttendanceManager attendanceSystem;
  User loggedInUser;
  bool isLoggedIn = false;
  clearScreen();

  while (true) {
    if (!isLoggedIn) {
      cout << BOLD_CYAN << "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
      cout << "         SISTEM ABSENSI SEKOLAH          \n";
      cout << "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" << RESET;
      cout << "  " << BOLD_CYAN << "[1]" << RESET << " Login\n";
      cout << "  " << BOLD_CYAN << "[2]" << RESET << " Register\n";
      cout << "  " << BOLD_RED << "[3]" << RESET << " Keluar\n\n";

      int mainChoice = promptInt("Pilih Menu >> ");

      switch (mainChoice) {
        case 1:
          if (authSystem.loginUser(loggedInUser)) {
            isLoggedIn = true;
            clearScreen();
            cout << BOLD_GREEN << "\n[v] LOGIN BERHASIL\n" << RESET;
            cout << "Selamat datang kembali, " << BOLD_CYAN << loggedInUser.name << RESET << "!\n\n";
          }
          break;

        case 2:
          authSystem.registerUser();
          break;

        case 3: {
          clearScreen();
          string frames[4] = {".   ", "..  ", "... ", "...."};
          for (int i = 5; i > 0; --i) { // Loop Hitungan Mundur (Detik)
            for (int j = 0; j < 4; ++j) { // Loop Bingkai Animasi (Titik)
              cout << CYAN << "Menutup sistem " << i << " detik" << frames[j] << "\r" << RESET << flush;
              delayMilliseconds(250); 
            }
          }
          clearScreen();
          cout << BOLD_GREEN << "Terima kasih telah menggunakan program ini!\n" << RESET;
          return 0;
        }

        default:
          clearScreen();
          cout << BOLD_RED << "[!] Pilihan tidak valid. Silakan pilih 1-3.\n\n" << RESET;
          break;
      }
    } else {
      cout << BOLD_CYAN << "\n         :: DASHBOARD " << loggedInUser.role << " ::\n";
      cout << "-----------------------------------------\n" << RESET;

      if (loggedInUser.role == "TEACHER") {
        cout << "  " << BOLD_CYAN << "[1]" << RESET << " Input Absensi Baru\n";
        cout << "  " << BOLD_CYAN << "[2]" << RESET << " Lihat Data Absensi\n";
        cout << "  " << BOLD_CYAN << "[3]" << RESET << " Rekap Kehadiran Siswa\n";
        cout << "  " << BOLD_CYAN << "[4]" << RESET << " Modifikasi Data Absensi\n";
        cout << "  " << BOLD_YELLOW << "[5]" << RESET << " Hapus Data Absensi\n";
        cout << "  " << BOLD_YELLOW << "[6]" << RESET << " Hapus Akun Siswa\n";   
        cout << "  " << BOLD_CYAN << "[7]" << RESET << " Export Laporan Absensi\n";
        cout << "  " << BOLD_CYAN << "[8]" << RESET << " Modifikasi Profil Pribadi\n";
        cout << "  " << BOLD_RED << "[9]" << RESET << " Logout\n\n";

        int userMenuChoice = promptInt("Pilih Menu >> ");

        switch (userMenuChoice) {
          case 1: attendanceSystem.inputAttendance(); break;
          case 2: attendanceSystem.viewAttendance(loggedInUser); break;
          case 3: attendanceSystem.countPresence(loggedInUser); break;
          case 4: attendanceSystem.modifyAttendance(); break;
          case 5: attendanceSystem.deleteAttendance(); break; 
          case 6: authSystem.deleteUser(); break;             
          case 7: attendanceSystem.exportAttendance(); break;
          case 8: authSystem.modifyProfile(loggedInUser); break;
          case 9:
            isLoggedIn = false;
            clearScreen();
            cout << BOLD_GREEN << "[v] Berhasil logout.\n\n" << RESET;
            break;
          default:
            clearScreen();
            cout << BOLD_RED << "[!] Pilihan tidak valid.\n\n" << RESET;
            break;
        }
      } else if (loggedInUser.role == "STUDENT") {
        cout << "  " << BOLD_CYAN << "[1]" << RESET << " Lihat Data Absensi Saya\n";
        cout << "  " << BOLD_CYAN << "[2]" << RESET << " Hitung Rekap Kehadiran\n";
        cout << "  " << BOLD_CYAN << "[3]" << RESET << " Modifikasi Profil Pribadi\n";
        cout << "  " << BOLD_RED << "[4]" << RESET << " Logout\n\n";

        int userMenuChoice = promptInt("Pilih Menu >> ");

        switch (userMenuChoice) {
          case 1: attendanceSystem.viewAttendance(loggedInUser); break;
          case 2: attendanceSystem.countPresence(loggedInUser); break;
          case 3: authSystem.modifyProfile(loggedInUser); break;
          case 4:
            isLoggedIn = false;
            clearScreen();
            cout << BOLD_GREEN << "[v] Berhasil logout.\n\n" << RESET;
            break;
          default:
            clearScreen();
            cout << BOLD_RED << "[!] Pilihan tidak valid.\n\n" << RESET;
            break;
        }
      }
    }
  }
  return 0;
}