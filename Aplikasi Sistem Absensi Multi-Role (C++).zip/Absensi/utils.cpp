#include "utils.h"

#include <cctype>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <sstream>

// Pustaka khusus OS untuk menyembunyikan input terminal
#ifdef _WIN32
#include <conio.h> // Untuk Windows (_getch)
#else
#include <termios.h> // Untuk Mac/Linux
#include <unistd.h>
#endif

using namespace std;

void clearScreen() {
#ifdef _WIN32
  system("cls");
#else
  system("clear");
#endif
}

void delayMilliseconds(int ms) {
    this_thread::sleep_for(chrono::milliseconds(ms));
}

string hashPassword(const string& password) {
  unsigned long hash = 5381;
  for (char c : password) {
    hash = ((hash << 5) + hash) + c; /* hash * 33 + c */
  }
  
  // Ubah hasil hash menjadi format Hexadecimal agar rapi di file .txt
  stringstream ss;
  ss << hex << hash;
  return ss.str();
}

string promptPasswordValidated(const string& prompt, size_t maxLen, bool required) {
  string password;
  while (true) {
    cout << BOLD_YELLOW << prompt << RESET;
    password = "";
    char ch;

#ifdef _WIN32
    // Logika Untuk Windows
    while ((ch = _getch()) != '\r') { // \r adalah tombol Enter di Windows
      if (ch == '\b') { // Jika tombol Backspace ditekan
        if (!password.empty()) {
          cout << "\b \b"; // Hapus bintang dari layar
          password.pop_back(); // Hapus huruf dari memori
        }
      } else if (password.length() < maxLen) {
        password += ch;
        cout << CYAN << '*' << RESET; // Cetak bintang ke layar
      }
    }
    cout << endl;
#else
    // Logika Untuk Mac / Linux
    struct termios oldt, newt;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ECHO | ICANON); // Matikan Echo terminal
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);

    while (read(STDIN_FILENO, &ch, 1) == 1 && ch != '\n') { // \n adalah Enter di Unix
      if (ch == 127 || ch == '\b') { // 127 adalah Backspace di Unix
        if (!password.empty()) {
          cout << "\b \b" << flush;
          password.pop_back();
        }
      } else if (password.length() < maxLen) {
        password += ch;
        cout << CYAN << '*' << RESET << flush;
      }
    }
    cout << endl;
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt); // Kembalikan terminal ke normal
#endif

    // Validasi Akhir Password
    if (!password.empty()) {
      bool hasSpace = false;
      for (char c : password) {
        if (isspace(c)) { hasSpace = true; break; }
      }
      if (hasSpace) {
        clearScreen();
        cout << BOLD_RED << "[ERROR] Password tidak boleh mengandung spasi!\n\n" << RESET;
        continue;
      }
      return password;
    } else {
      if (!required) return password;
      clearScreen();
      cout << BOLD_RED << "[ERROR] Password ini tidak boleh kosong!\n\n" << RESET;
    }
  }
}

int promptInt(const string& prompt) {
  string input;
  cout << BOLD_YELLOW << prompt << RESET;
  getline(cin, input);

  if (input.empty()) return -1;
  if (input.length() > 1 && input[0] == '0') return -1;

  for (char c : input) {
    if (!isdigit(c)) return -1; // -1 agar masuk ke case default (Pilihan tidak valid)
  }

  try {
    return stoi(input);
  } catch(...) {
    return -1;
  }
}

string promptValidated(const string& prompt, size_t maxLen, bool required) {
  string input;
  while (true) {
    cout << BOLD_YELLOW << prompt << RESET;
    getline(cin, input);

    if (!input.empty()) {
      if (input.length() <= maxLen) {
        bool hasSpace = false;
        for (char c : input) {
          if (isspace(c)) {
            hasSpace = true;
            break;
          }
        }
        if (hasSpace) {
          clearScreen();
          cout << BOLD_RED << "[ERROR] Input tidak boleh mengandung spasi!\n\n" << RESET;
          continue;
        }
        return input;
      }
      clearScreen();
      cout << BOLD_RED << "[ERROR] Input maksimal " << maxLen << " karakter!\n\n" << RESET;
    } else {
      if (!required) return input;
      clearScreen();
      cout << BOLD_RED << "[ERROR] Input ini tidak boleh kosong!\n\n" << RESET;
    }
  }
}

string promptNameValidated(const string& prompt, size_t maxLen, bool required) {
  string input;
  while (true) {
    cout << BOLD_YELLOW << prompt << RESET;
    getline(cin, input);

    if (!input.empty()) {
      if (input.length() > maxLen) {
        clearScreen();
        cout << BOLD_RED << "[ERROR] Input maksimal " << maxLen << " karakter!\n\n" << RESET;
        continue;
      }

      bool isInvalidChar = false;
      for (char c : input) {
        if (!isalpha(c) && !isspace(c)) {
          isInvalidChar = true;
          break;
        }
      }

      if (isInvalidChar) {
        clearScreen();
        cout << BOLD_RED << "[ERROR] Nama tidak valid! Hanya boleh berisi huruf dan spasi.\n\n" << RESET;
        continue;
      }

      // Normalisasi (Title Case)
      bool newWord = true;
      for (size_t i = 0; i < input.length(); ++i) {
        if (isspace(input[i])) {
          input[i] = ' ';
          newWord = true;
        } else if (newWord) {
          input[i] = toupper(input[i]);
          newWord = false;
        } else {
          input[i] = tolower(input[i]);
        }
      }

      return input;
    } else {
      if (!required) return input;
      clearScreen();
      cout << BOLD_RED << "[ERROR] Input ini tidak boleh kosong!\n\n" << RESET;
    }
  }
}

string promptDigitsValidated(const string& prompt, size_t maxLen,
                             bool required) {
  string input;
  while (true) {
    cout << BOLD_YELLOW << prompt << RESET;
    getline(cin, input);

    if (!input.empty()) {
      if (input.length() > maxLen) {
        clearScreen();
        cout << BOLD_RED << "[ERROR] Input maksimal " << maxLen << " digit!\n\n" << RESET;
        continue;
      }

      bool allDigits = true;
      for (char c : input) {
        if (!isdigit(c)) {
          allDigits = false;
          break;
        }
      }

      if (!allDigits) {
        clearScreen();
        cout << BOLD_RED << "[ERROR] Input tidak valid! Harap masukkan HANYA ANGKA.\n\n" << RESET;
        continue;
      }
      return input;
    } else {
      if (!required) return input;
      clearScreen();
      cout << BOLD_RED << "[ERROR] Input ini tidak boleh kosong!\n\n" << RESET;
    }
  }
}

string promptDateValidated(const string& prompt) {
  string input;
  while (true) {
    cout << BOLD_YELLOW << prompt << RESET;
    getline(cin, input);

    if (input.empty()) {
      clearScreen();
      cout << BOLD_RED << "[ERROR] Input tanggal tidak boleh kosong!\n\n" << RESET;
      continue;
    }

    if (input.length() != 10 || input[2] != '-' || input[5] != '-') {
      clearScreen();
      cout << BOLD_RED << "[ERROR] Format salah! Harus DD-MM-YYYY (contoh: 25-12-2024).\n\n" << RESET;
      continue;
    }

    bool allDigits = true;
    for (int i = 0; i < 10; ++i) {
      if (i == 2 || i == 5) continue;
      if (!isdigit(input[i])) {
        allDigits = false;
        break;
      }
    }

    if (!allDigits) {
      clearScreen();
      cout << BOLD_RED << "[ERROR] Tanggal harus angka! (contoh: 25-12-2024).\n\n" << RESET;
      continue;
    }

    int d = stoi(input.substr(0, 2)); // Hari
    int m = stoi(input.substr(3, 2)); // Bulan
    int y = stoi(input.substr(6, 4)); // Tahun

    if (y < 2000 || y > 2100) {
      clearScreen();
      cout << BOLD_RED << "[ERROR] Tahun tidak realistis! Harap masukkan tahun antara 2000 hingga 2100.\n\n" << RESET;
      continue;
    }

    bool isValidDate = true;
    if (m < 1 || m > 12) isValidDate = false;
    else if (d < 1 || d > 31) isValidDate = false;
    else if (m == 4 || m == 6 || m == 9 || m == 11) {
      if (d > 30) isValidDate = false;
    } else if (m == 2) {
      // RUMUS 3 SYARAT KABISAT GREGORIAN
      bool isLeap = (y % 4 == 0 && (y % 100 != 0 || y % 400 == 0));
      if (isLeap && d > 29) isValidDate = false;
      else if (!isLeap && d > 28) isValidDate = false;
    }

    if (!isValidDate) {
      clearScreen();
      cout << BOLD_RED << "[ERROR] Tanggal tidak valid di kalender!\n\n" << RESET;
      continue;
    }
    return input;
  }
}

// Mengubah string tanggal menjadi total hitungan hari (Absolute Days)
int dateToAbsoluteDays(const string& dateStr) {
    int d = stoi(dateStr.substr(0, 2));
    int m = stoi(dateStr.substr(3, 2));
    int y = stoi(dateStr.substr(6, 4));

    // Rumus Matematika Kalender Gregorian
    if (m <= 2) {
        y--;
        m += 12;
    }
    return 365 * y + y / 4 - y / 100 + y / 400 + (153 * m - 457) / 5 + d - 306;
}

string promptWeekValidated(const string& prompt) {
  string input;
  while (true) {
    input = promptDigitsValidated(prompt, 2, true);

    if (stoi(input) > 0) {
      return input;
    }

    clearScreen();
    cout << BOLD_RED << "[ERROR] Minggu tidak boleh 0.\n\n" << RESET;
  }
}

string promptStudentIdValidated(const string& prompt) {
  string input;
  while (true) {
    cout << BOLD_YELLOW << prompt << RESET;
    getline(cin, input);

    if (input.empty()) {
      clearScreen();
      cout << BOLD_RED << "[ERROR] ID Siswa tidak boleh kosong!\n\n" << RESET;
      continue;
    }

    if (input.length() == 5) {
      input[0] = toupper(input[0]);
      input[1] = toupper(input[1]);

      if (input[0] == 'S' && input[1] == 'T' && isdigit(input[2]) && isdigit(input[3]) && isdigit(input[4])) {
        return input;
      }
    }

    clearScreen();
    cout << BOLD_RED << "[ERROR] ID tidak valid! Wajib 'ST' + 3 angka (contoh: ST001).\n\n" << RESET;
  }
}

string promptFileNameValidated(const string& prompt, size_t maxLen) {
  string input;
  while (true) {
    cout << BOLD_YELLOW << prompt << RESET;
    getline(cin, input);

    if (!input.empty()) {
      if (input.length() > maxLen) {
        clearScreen();
        cout << BOLD_RED << "[ERROR] Nama file maksimal " << maxLen << " karakter!\n\n" << RESET;
        continue;
      }

      // Blokir Karakter Ilegal Windows
      bool isInvalidChar = false;
      string forbidden = "\\/:*?\"<>|";
      for (char c : input) {
        if (forbidden.find(c) != string::npos) {
          isInvalidChar = true;
          break;
        }
      }

      if (isInvalidChar) {
        clearScreen();
        cout << BOLD_RED << "[ERROR] Nama file dilarang mengandung simbol (\\ / : * ? \" < > |)\n\n" << RESET;
        continue;
      }

      bool newWord = true;
      for (size_t i = 0; i < input.length(); ++i) {
        if (isspace(input[i])) {
          input[i] = '_';
          newWord = true;
        } else if (input[i] == '_' || input[i] == '-') {
          newWord = true; 
        } else if (isalpha(input[i])) {
          if (newWord) {
            input[i] = toupper(input[i]);
            newWord = false;
          } else {
            input[i] = tolower(input[i]);
          }
        } else {
          newWord = false;
        }
      }
      return input;
    } else {
      clearScreen();
      cout << BOLD_RED << "[ERROR] Nama file tidak boleh kosong!\n\n" << RESET;
    }
  }
}