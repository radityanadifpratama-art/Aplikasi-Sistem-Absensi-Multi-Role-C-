#pragma once
#include <vector>

#include "models.h"
using namespace std;

class AttendanceManager {
 private:
  vector<AttendanceRecord> attendanceList;
  const string ATTENDANCE_FILE = "attendance_db.txt";

 public:
  AttendanceManager(); // Default constructor
  void loadAttendance();
  void saveAttendance();
  void inputAttendance();
  void modifyAttendance();
  void viewAttendance(const User& user);
  void countPresence(const User& user);
  void deleteAttendance();
  void exportAttendance();
};