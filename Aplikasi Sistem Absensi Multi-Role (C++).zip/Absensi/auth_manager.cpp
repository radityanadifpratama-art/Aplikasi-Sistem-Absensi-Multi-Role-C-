#include "auth_manager.h"
#include <fstream>
#include <iostream>
#include "utils.h"
using namespace std;

// Default constructor
AuthManager::AuthManager() {
    loadUsers();
}

void AuthManager::loadUsers() {
    userList.clear();
    ifstream file(FILE_NAME);
    string line;

    if (file.is_open()) {
        while (getline(file,line)) {
            if (line.empty()) continue;
            istringstream ss(line);
            User u;
            ss >> u.id >> u.name >> u.password >> u.role >> u.phone;

            for (char& c : u.name) {
                if (c == '_') c = ' ';
            }
            userList.push_back(u);
        }
        file.close();
    }
}

void AuthManager::saveUsers() {
    ofstream file(FILE_NAME);
    if (file.is_open()) {
        for (const auto& u : userList) {
            file << u.formatRecord() << "\n";
        }
        file.close();
    }
}

void AuthManager::registerUser() {
    clearScreen();
    int roleChoice;
    while (true) {
        cout << BOLD_CYAN << "\n          :: REGISTRASI AKUN ::\n";
        cout << "-----------------------------------------\n" << RESET;
        cout << "  " << BOLD_CYAN << "[1]" << RESET << " Guru (Teacher)\n";
        cout << "  " << BOLD_CYAN << "[2]" << RESET << " Siswa (Student)\n\n";

        roleChoice = promptInt("Pilih Peran >> ");
        if (roleChoice == 1 || roleChoice == 2) break;
        
        clearScreen();
        cout << BOLD_RED << "[!] Pilihan tidak valid! Harap pilih 1 atau 2.\n" << RESET;
    }

    string roleStr = (roleChoice == 1) ? "TEACHER" : "STUDENT";
    string idPrefix = (roleChoice == 1) ? "TC" : "ST";

    clearScreen();
    string numericId = promptDigitsValidated("Masukkan Nomor ID Unik (Max 3 digit angka, misal '001') : ", 3);
    string newId = idPrefix + numericId;

    for (const auto& u : userList) {
        if (u.id == newId) {
            cout << BOLD_RED << "\n[GAGAL] ID " << newId << " sudah terdaftar.\n" << RESET;
            return;
        }
    }

    clearScreen();
    string newName = promptNameValidated("Masukkan Nama (Max 14 Karakter) : ", 14);
    clearScreen();
    string newPass = promptPasswordValidated("Masukkan Password (Max 14 Karakter) : ", 14);
    string hashedPass = hashPassword(newPass);
    clearScreen();
    string newPhone = promptDigitsValidated("Masukkan Nomor Telepon (Max 14 digit angka) : ", 14);

    userList.push_back(User(newId, newName, hashedPass, roleStr, newPhone));
    saveUsers();

    clearScreen();
    clearScreen();
    cout << BOLD_GREEN << "\n[v] Registrasi Berhasil!\n" << RESET;
    cout << "ID Login Anda adalah : " << BOLD_CYAN << newId << RESET << "\n\n";
}

bool AuthManager::loginUser(User& loggedInUser) {
    static int failedAttempts = 0;

    if (failedAttempts >= 5) {
        clearScreen();
        cout << BOLD_RED << "\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        cout << "        !!! LOCKDOWN KEAMANAN !!!        \n";
        cout << "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" << RESET;
        cout << "Anda telah gagal login 5 kali berturut-turut.\n";
        cout << "Sistem dikunci untuk mencegah serangan Brute Force.\n\n";

        string frames[] = {".   ", "..  ", "... ", "...."};
        for (int i = 60; i > 0; --i) { // Loop Hitungan Mundur (Detik)
            for (int j = 0; j < 4; ++j) { // Loop Bingkai Animasi (Titik)
                cout << BOLD_YELLOW << "Sistem akan terbuka dalam " << i << " detik" << frames[j] << "\r" << RESET << flush;
                delayMilliseconds(250);
            }
        }
        cout << "                                                    \r"; 
        failedAttempts = 0; 
        clearScreen();
    }


    clearScreen();
    cout << BOLD_CYAN << "\n           :: LOGIN SISTEM ::\n";
    cout << "-----------------------------------------\n" << RESET;
    string inputId = promptValidated("ID Pengguna : ", 10);
    string inputPass = promptPasswordValidated("Password    : ", 14);
    string hashedInputPass = hashPassword(inputPass);

    for (const auto& u : userList) {
        if (u.id == inputId && u.password == hashedInputPass) {
            failedAttempts = 0;
            loggedInUser = u;
            return true;
        }
    }
    
    // Gagal login, Tambah counter
    failedAttempts++;
    clearScreen();
    cout << BOLD_RED << "\n[x] Login Gagal! ID atau password salah.\n";
    cout << "Percobaan gagal: " << failedAttempts << "/5\n" << RESET;
    return false;
}

void AuthManager::modifyProfile(User& loggedInUser) {
    clearScreen();
    cout << BOLD_CYAN << "\n          :: PROFIL SAAT INI ::\n";
    cout << "-----------------------------------------\n" << RESET;
    cout << "ID       : " << BOLD_CYAN << loggedInUser.id << RESET << "\n";
    cout << "Nama     : " << loggedInUser.name << "\n";
    cout << "Telepon  : " << loggedInUser.phone << "\n";
    cout << "Role     : " << loggedInUser.role << "\n";
    cout << CYAN << "-----------------------------------------\n" << RESET;
    cout << "Tekan Enter (kosongkan) jika tidak ingin mengubah data tertentu.\n\n";

    string val = promptNameValidated("Ubah Nama (Saat ini : " + loggedInUser.name + ") >> ", 14, false);
    if (!val.empty()) loggedInUser.name = val;

    cout << "Ubah Password (kosongkan jika tidak ingin mengubah):\n";
    string valPass = promptPasswordValidated(">> ", 14, false);
    if (!valPass.empty()) loggedInUser.password = hashPassword(valPass);

    val = promptDigitsValidated("Ubah Telepon (Saat ini : " + loggedInUser.phone + ") >> ", 14, false);
    if (!val.empty()) loggedInUser.phone = val;

    // Sinkronisasi data di memory
    for (auto& u : userList) {
        if (u.id == loggedInUser.id) {
            u = loggedInUser;
            break;
        }
    }
    saveUsers();

    clearScreen();
    cout << BOLD_GREEN << "\n[v] Profil berhasil diperbarui!\n\n" << RESET;
}

void AuthManager::deleteUser() {
    clearScreen();
    cout << BOLD_CYAN << "\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    cout << "          DAFTAR AKUN SISWA AKTIF        \n";
    cout << "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" << RESET;
    
    bool hasStudent = false;
    for (const auto& u : userList) {
        if (u.role == "STUDENT") {
            hasStudent = true;
            cout << " ID: " << BOLD_YELLOW << left << setw(8) << u.id << RESET 
                 << " | Nama: " << CYAN << u.name << RESET << "\n";
        }
    }
    
    if (!hasStudent) {
        cout << YELLOW << " Belum ada akun siswa yang terdaftar.\n" << RESET;
        cout << BOLD_CYAN << "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" << RESET;
        return;
    }
    cout << BOLD_CYAN << "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" << RESET;

    string targetId = promptValidated("Masukkan ID Siswa yang akan dihapus (Ketik 0 batal) >> ", 5);
    
    if (targetId == "0") {
        clearScreen();
        return;
    }
    
    bool found = false;
    for (auto it = userList.begin(); it != userList.end(); ++it) {
        if (it->id == targetId) {
            found = true;
            
            if (it->role == "TEACHER") {
                clearScreen();
                cout << BOLD_RED << "\n[x] AKSES DITOLAK! Anda tidak diizinkan menghapus akun Guru.\n\n" << RESET;
                return;
            }
            
            cout << "\nData ditemukan:\n";
            cout << "Nama   : " << BOLD_CYAN << it->name << RESET << "\n";
            cout << "Role   : " << it->role << "\n\n";
            
            string confirm = promptValidated(string(BOLD_RED) + "PERINGATAN: Akun ini akan dihapus permanen. Lanjutkan? (Y/N) >> " + string(RESET), 1);
            
            if (confirm == "Y" || confirm == "y") {
                userList.erase(it); 
                saveUsers();        
                clearScreen();
                cout << BOLD_GREEN << "\n[v] Akun siswa (" << targetId << ") berhasil dihapus secara permanen.\n\n" << RESET;
            } else {
                clearScreen();
                cout << CYAN << "\n[-] Penghapusan dibatalkan.\n\n" << RESET;
            }
            break; 
        }
    }
    
    if (!found) {
        clearScreen();
        cout << BOLD_RED << "\n[x] ID " << targetId << " tidak ditemukan di dalam database.\n\n" << RESET;
    }
}