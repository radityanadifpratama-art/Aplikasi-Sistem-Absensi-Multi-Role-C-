#pragma once
#include <vector>

#include "models.h"
using namespace std;

class AuthManager {
 private:
  vector<User> userList;
  const string FILE_NAME = "users.txt";

 public:
  AuthManager(); // Default constructor
  void loadUsers();
  void saveUsers();
  void registerUser();
  bool loginUser(User& loggedInUser);
  void modifyProfile(User& loggedInUser);
  void deleteUser();
};