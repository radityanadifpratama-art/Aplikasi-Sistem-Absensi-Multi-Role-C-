#include "attendance_manager.h"
#include "utils.h"
#include <iostream>
#include <fstream>
#include <set>
#include <cmath>
using namespace std;

AttendanceManager::AttendanceManager() {
    loadAttendance();
}

void AttendanceManager::loadAttendance() {
    attendanceList.clear();
    ifstream file(ATTENDANCE_FILE);
    string line;

    if (file.is_open()) {
        while (getline(file, line)) {
            if (line.empty()) continue;
            istringstream ss(line);
            AttendanceRecord rec;
            ss >> rec.date >> rec.week >> rec.studentId >> rec.studentName >> rec.status;
            for (char& c : rec.studentName) {
                if (c == '_') c = ' ';
            }
            attendanceList.push_back(rec);
        }
        file.close();
    }
}

void AttendanceManager::saveAttendance() {
    ofstream file(ATTENDANCE_FILE);
    if (file.is_open()) {
        for (const auto& rec : attendanceList) {
            file << rec.formatRecord() << "\n";
        }
        file.close();
    }
}

void AttendanceManager::inputAttendance() {
    clearScreen();
    string currentDate;
    string currentWeek;

    while (true) {
        currentDate = promptDateValidated("Masukkan Tanggal (DD-MM-YYYY) : ");
        currentWeek = promptWeekValidated("Masukkan Minggu ke- (Hanya Angka) : ");

        // Mengecek agar jarak hari selalu sinkron dengan jarak minggu (7 hari)
        int newD = dateToAbsoluteDays(currentDate);
        int newW = stoi(currentWeek);
        
        bool isLogicalError = false;
        string conflictDate = "";
        string conflictWeek = "";
        string errorMsg = "";

        // Bandingkan input tanggal ini dengan semua data historis di database
        for (const auto& rec : attendanceList) {
            int recD = dateToAbsoluteDays(rec.date);
            int recW = stoi(rec.week);
            
            int dayDiff = abs(newD - recD);   // Selisih jarak hari
            int weekDiff = abs(newW - recW);  // Selisih jarak minggu
            
            // Aturan 1: Arah Kronologis Terbalik
            if ((newD > recD && newW < recW) || (newD < recD && newW > recW)) {
                isLogicalError = true;
                conflictDate = rec.date;
                conflictWeek = rec.week;
                errorMsg = "Arah waktu terbalik! Tanggal yang lebih baru tidak boleh memiliki minggu yang lebih kecil/lama.";
                break;
            } 
            // Aturan 2: Lompat Minggu Terlalu Cepat (Contoh: Beda 1 hari tapi lompat 1 minggu)
            else if (dayDiff < weekDiff * 7) {
                isLogicalError = true;
                conflictDate = rec.date;
                conflictWeek = rec.week;
                errorMsg = "Jarak hari hanya (" + to_string(dayDiff) + " hari). Belum mencapai " + to_string(weekDiff * 7) + " hari untuk melompat " + to_string(weekDiff) + " minggu.";
                break;
            } 
            // Aturan 3: Lupa Lompat Minggu (Contoh: Beda 8 hari tapi masih di minggu yang sama)
            else if (dayDiff > (weekDiff * 7) + 6) {
                isLogicalError = true;
                conflictDate = rec.date; conflictWeek = rec.week;
                errorMsg = "Jarak hari sangat jauh (" + to_string(dayDiff) + " hari). Sudah melewati batas maksimal hari untuk minggu tersebut (wajib ganti minggu).";
                break;
            }
        }

        if (isLogicalError) {
            clearScreen();
            cout << BOLD_RED << "\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
            cout << "       [!] LOGIKA WAKTU ERROR [!]        \n";
            cout << "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" << RESET;
            cout << "Input Saat Ini   : " << BOLD_CYAN << currentDate << RESET << " (Minggu " << currentWeek << ")\n";
            cout << "Konflik Histori  : " << BOLD_YELLOW << conflictDate << RESET << " (Minggu " << conflictWeek << ")\n\n";
            cout << BOLD_RED << "Alasan Penolakan:\n" << RESET;
            cout << errorMsg << "\n\n";
            cout << "Sistem membatalkan input demi menjaga keutuhan Kalender Absensi.\n";
            cout << "Silakan koreksi ketikan tanggal atau minggu Anda!\n\n";
            continue;
        }
        break;
    }

    string isContinue;
    do {
        clearScreen();
        cout << BOLD_CYAN << "\n           :: INPUT ABSENSI ::\n";
        cout << "-----------------------------------------\n" << RESET;
        cout << "Tanggal : " << BOLD_CYAN << currentDate << RESET << " (Minggu ke-" << currentWeek << ")\n\n";

        string stuId = promptStudentIdValidated("Masukkan ID Siswa (Contoh: ST001) : ");
        
        bool alreadyExists = false;
        for (const auto& rec : attendanceList) {
            if (rec.date == currentDate && rec.studentId == stuId) {
                alreadyExists = true; 
                break; 
            }
        }
        
        if (alreadyExists) {
            cout << BOLD_RED << "\n[x] DITOLAK! Siswa " << stuId << " sudah diabsen hari ini.\n" << RESET;
            isContinue = promptValidated("Input siswa lain untuk tanggal ini? (Y/N) : ", 1);
            continue;
        }

        string stuName = promptNameValidated("Masukkan Nama Siswa (Maks 19 Huruf) : ", 19);

        int statusChoice;
        while (true) {
            cout << "\nStatus Kehadiran:\n";
            cout << "  " << BOLD_CYAN << "[1]" << RESET << " Hadir\n";
            cout << "  " << BOLD_CYAN << "[2]" << RESET << " Izin\n";
            cout << "  " << BOLD_CYAN << "[3]" << RESET << " Sakit\n";
            cout << "  " << BOLD_CYAN << "[4]" << RESET << " Alpa\n";
            statusChoice = promptInt("Pilihan >> ");

            if (statusChoice >= 1 && statusChoice <= 4) break;
            clearScreen();
            cout << BOLD_RED << "[!] Pilihan tidak valid!\n" << RESET;
        }

        string finalStatus;
        if (statusChoice == 1) finalStatus = "Hadir";
        else if (statusChoice == 2) finalStatus = "Izin";
        else if (statusChoice == 3) finalStatus = "Sakit";
        else finalStatus = "Alpa";

        attendanceList.push_back(AttendanceRecord(currentDate, currentWeek, stuId, stuName, finalStatus));

        cout << BOLD_GREEN << "\n[v] Data berhasil ditambahkan!\n" << RESET;
        isContinue = promptValidated("Input absensi lagi untuk tanggal " + currentDate + "? (Y/N) : ", 1);
    } while (isContinue == "Y" || isContinue == "y");

    saveAttendance();
    clearScreen();
    cout << BOLD_GREEN << "[v] Semua data absensi berhasil disimpan.\n\n" << RESET;
}

void AttendanceManager::modifyAttendance() {
    clearScreen();
    if (attendanceList.empty()) {
        cout << CYAN << "Belum ada riwayat data absensi.\n\n" << RESET;
        return;
    }

    cout << BOLD_CYAN << "\n      :: MODIFIKASI DATA ABSENSI ::\n";
    cout << "-----------------------------------------\n" << RESET;
    for (size_t i = 0; i < attendanceList.size(); ++i) {
        cout << BOLD_CYAN << "[" << i + 1 << "] " << RESET 
             << attendanceList[i].date << " | " 
             << attendanceList[i].studentId << " | " 
             << attendanceList[i].studentName << " | Status: ";
             
        string stat = attendanceList[i].status;
        if (stat == "Hadir") cout << GREEN << stat << RESET << "\n";
        else if (stat == "Alpa") cout << RED << stat << RESET << "\n";
        else cout << YELLOW << stat << RESET << "\n";
    }
    cout << "-----------------------------------------\n";
    
    int index = promptInt("\nPilih Nomor Data (Ketik 0 untuk batal) >> ");
    if (index == 0) {
        clearScreen();
        return;
    }
    if (index < 1 || index > static_cast<int>(attendanceList.size())) {
        clearScreen();
        cout << BOLD_RED << "[!] Nomor data tidak valid!\n\n" << RESET;
        return;
    }

    int realIndex = index - 1;

    clearScreen();
    cout << BOLD_CYAN << "\n          :: UBAH DATA NO. " << index << " ::\n";
    cout << "-----------------------------------------\n" << RESET;
    cout << "Siswa : " << CYAN << attendanceList[realIndex].studentName << RESET 
         << " (" << attendanceList[realIndex].date << ")\n\n";
    
    int statusChoice;
    while (true) {
        cout << "Pilih Status Baru:\n";
        cout << "  " << BOLD_CYAN << "[1]" << RESET << " Hadir\n";
        cout << "  " << BOLD_CYAN << "[2]" << RESET << " Izin\n";
        cout << "  " << BOLD_CYAN << "[3]" << RESET << " Sakit\n";
        cout << "  " << BOLD_CYAN << "[4]" << RESET << " Alpa\n";
        statusChoice = promptInt("Pilihan >> ");
        if (statusChoice >= 1 && statusChoice <= 4) break;
        cout << BOLD_RED << "[!] Pilihan tidak valid!\n" << RESET;
    }

    string finalStatus;
    if (statusChoice == 1) finalStatus = "Hadir";
    else if (statusChoice == 2) finalStatus = "Izin";
    else if (statusChoice == 3) finalStatus = "Sakit";
    else finalStatus = "Alpa";

    attendanceList[realIndex].status = finalStatus;
    saveAttendance();

    clearScreen();
    cout << BOLD_GREEN << "\n[v] Data absensi berhasil diubah!\n\n" << RESET;
}

void AttendanceManager::viewAttendance(const User& user) {
    clearScreen();
    string filterDate = "";
    string filterWeek = "";
    
    if (user.role == "TEACHER") {
        cout << BOLD_CYAN << "\n        :: FILTER DATA ABSENSI ::\n";
        cout << "-----------------------------------------\n" << RESET;
        cout << "  " << BOLD_CYAN << "[1]" << RESET << " Semua Data\n";
        cout << "  " << BOLD_CYAN << "[2]" << RESET << " Per Tanggal\n";
        cout << "  " << BOLD_CYAN << "[3]" << RESET << " Per Minggu\n\n";
        int filterChoice = promptInt("Pilihan >> ");
        if (filterChoice == 2) filterDate = promptDateValidated("Masukkan Tanggal (DD-MM-YYYY) : ");
        else if (filterChoice == 3) filterWeek = promptWeekValidated("Masukkan Minggu ke-: ");
        clearScreen();
    }
    
    if (!filterDate.empty()) cout << CYAN << "[Filter] Tanggal : " << filterDate << RESET << "\n";
    if (!filterWeek.empty()) cout << CYAN << "[Filter] Minggu  : Ke-" << filterWeek << RESET << "\n";

    if (attendanceList.empty()) {
        cout << CYAN << "Belum ada riwayat data absensi.\n\n" << RESET;
        return;
    }

    cout << BOLD_CYAN << "-----------------------------------------------------------------------------\n";
    cout << " TANGGAL         | MINGGU | ID SISWA | NAMA SISWA           | STATUS     \n";
    cout << "-----------------------------------------------------------------------------\n" << RESET;

    bool hasData = false;
    for (const auto& rec : attendanceList) {
        // Logika Filter
        if (user.role == "STUDENT" && rec.studentId != user.id) continue;
        if (!filterDate.empty() && rec.date != filterDate) continue;
        if (!filterWeek.empty() && rec.week != filterWeek) continue;

        hasData = true;
        string coloredStatus;
        if (rec.status == "Hadir") coloredStatus = GREEN + rec.status + RESET;
        else if (rec.status == "Alpa") coloredStatus = RED + rec.status + RESET;
        else coloredStatus = YELLOW + rec.status + RESET;
        
        int colorLenOffset = coloredStatus.length() - rec.status.length();

        int offset = coloredStatus.length() - rec.status.length();

        cout << " " << left << setw(15) << rec.date 
             << " | " << left << setw(6) << rec.week
             << " | " << left << setw(8) << rec.studentId
             << " | " << left << setw(20) << rec.studentName 
             << " | " << left << setw(10 + offset) << coloredStatus << "\n";
    }

     if (!hasData) {
         cout << " " << CYAN << setw(73) << "   ( Tidak ada data yang cocok )   " << RESET << "\n";
    }
    cout << BOLD_CYAN << "-----------------------------------------------------------------------------\n\n" << RESET;
}

void AttendanceManager::countPresence(const User& user) {
    clearScreen();
    string filterDate = "";
    string filterWeek = "";

    if (user.role == "TEACHER") {
        cout << BOLD_CYAN << "\n        :: FILTER REKAPITULASI ::\n";
        cout << "-----------------------------------------\n" << RESET;
        cout << "  " << BOLD_CYAN << "[1]" << RESET << " Semua Data\n";
        cout << "  " << BOLD_CYAN << "[2]" << RESET << " Per Tanggal\n";
        cout << "  " << BOLD_CYAN << "[3]" << RESET << " Per Minggu\n\n";
        int filterChoice = promptInt("Pilihan >> ");
        if (filterChoice == 2) filterDate = promptDateValidated("Masukkan Tanggal (DD-MM-YYYY) : ");
        else if (filterChoice == 3) filterWeek = promptWeekValidated("Masukkan Minggu ke- : ");
        clearScreen();
    }

    int presentCount = 0, excusedCount = 0, sickCount = 0, absentCount = 0, validRecords = 0;
    set<string> uniqueStudents;

    for (const auto& rec : attendanceList) {
        if (user.role == "STUDENT" && rec.studentId != user.id) continue;
        if (!filterDate.empty() && rec.date != filterDate) continue;
        if (!filterWeek.empty() && rec.week != filterWeek) continue;

        validRecords++;
        uniqueStudents.insert(rec.studentId);

        if (rec.status == "Hadir") presentCount++;
        else if (rec.status == "Izin") excusedCount++;
        else if (rec.status == "Sakit") sickCount++;
        else if (rec.status == "Alpa") absentCount++;
    }

     cout << BOLD_CYAN << "\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    cout << "               REKAPITULASI KEHADIRAN               \n";
    cout << "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" << RESET;
    
    if (user.role == "STUDENT") {
        cout << " Profil  : " << BOLD_CYAN << user.name << " (" << user.id << ")\n" << RESET;
        cout << "----------------------------------------------------\n";
        cout << " Total Hadir   : " << BOLD_GREEN << presentCount << RESET << " kali\n";
        cout << " Total Izin    : " << YELLOW << excusedCount << RESET << " kali\n";
        cout << " Total Sakit   : " << YELLOW << sickCount << RESET << " kali\n";
        cout << " Total Alpa    : " << BOLD_RED << absentCount << RESET << " kali\n";
    } else {
        string tgl = filterDate.empty() ? "Semua Tanggal" : filterDate;
        string mgg = filterWeek.empty() ? "Semua Minggu" : "Ke-" + filterWeek;
        
        cout << " Filter Tanggal : " << CYAN << tgl << RESET << "\n";
        cout << " Filter Minggu  : " << CYAN << mgg << RESET << "\n";
        cout << "----------------------------------------------------\n";
        cout << " Jumlah Siswa   : " << CYAN << uniqueStudents.size() << " Siswa\n" << RESET;
        cout << " Total Riwayat  : " << CYAN << validRecords << " Data\n" << RESET;
        cout << "----------------------------------------------------\n";
        cout << " Status Hadir   : " << BOLD_GREEN << presentCount << RESET << " data\n";
        cout << " Status Izin    : " << YELLOW << excusedCount << RESET << " data\n";
        cout << " Status Sakit   : " << YELLOW << sickCount << RESET << " data\n";
        cout << " Status Alpa    : " << BOLD_RED << absentCount << RESET << " data\n";
    }
    cout << BOLD_CYAN << "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" << RESET;
}

void AttendanceManager::deleteAttendance() {
    clearScreen();
    if (attendanceList.empty()) {
        cout << CYAN << "Belum ada riwayat data absensi untuk dihapus.\n\n" << RESET;
        return;
    }

    cout << BOLD_CYAN << "\n        :: HAPUS DATA ABSENSI ::\n";
    cout << "-----------------------------------------\n" << RESET;
    for (size_t i = 0; i < attendanceList.size(); ++i) {
    cout << BOLD_CYAN << "[" << i + 1 << "] " << RESET 
             << attendanceList[i].date << " | " 
             << attendanceList[i].studentId << " | " 
             << attendanceList[i].studentName << " | Status: ";
             
        string stat = attendanceList[i].status;
        if (stat == "Hadir") cout << GREEN << stat << RESET << "\n";
        else if (stat == "Alpa") cout << RED << stat << RESET << "\n";
        else cout << YELLOW << stat << RESET << "\n";
    }
    cout << "-----------------------------------------\n";
    
    int index = promptInt("\nPilih Nomor Data yang akan dihapus (Ketik 0 untuk batal) >> ");
    if (index == 0) {
        clearScreen();
        return;
    }
    if (index < 1 || index > static_cast<int>(attendanceList.size())) {
        clearScreen();
        cout << BOLD_RED << "[!] Nomor data tidak valid!\n\n" << RESET;
        return;
    }

    int realIndex = index - 1;
    clearScreen();
    cout << BOLD_CYAN << "\n        :: KONFIRMASI HAPUS NO. " << index << " ::\n";
    cout << "-----------------------------------------\n" << RESET;
    cout << "Tanggal : " << attendanceList[realIndex].date << "\n";
    cout << "Siswa   : " << BOLD_CYAN << attendanceList[realIndex].studentName << RESET << " (" << attendanceList[realIndex].studentId << ")\n";
    cout << "Status  : " << attendanceList[realIndex].status << "\n\n";
    
    string confirm = promptValidated(string(BOLD_RED) + "Hapus data absensi ini secara permanen? (Y/N) >> " + string(RESET), 1);
            
    if (confirm == "Y" || confirm == "y") {
        attendanceList.erase(attendanceList.begin() + realIndex);
        saveAttendance();
        
        clearScreen();
        cout << BOLD_GREEN << "\n[v] Data absensi berhasil dihapus!\n\n" << RESET;
    } else {
        clearScreen();
        cout << CYAN << "\n[-] Penghapusan dibatalkan.\n\n" << RESET;
    }
}

void AttendanceManager::exportAttendance() {
    clearScreen();
    if (attendanceList.empty()) {
        cout << CYAN << "Belum ada data absensi untuk diekspor.\n\n" << RESET;
        return;
    }

    cout << BOLD_CYAN << "\n         :: EXPORT LAPORAN ABSENSI ::\n";
    cout << "-----------------------------------------\n" << RESET;
    cout << "  " << BOLD_CYAN << "[1]" << RESET << " Format Notepad (.txt)  - Teks Biasa\n";
    cout << "  " << BOLD_CYAN << "[2]" << RESET << " Format Excel (.csv)    - Tabel\n\n";

    int exportChoice = promptInt("Pilih Format Laporan >> ");

    if (exportChoice != 1 && exportChoice != 2) {
        clearScreen();
        cout << BOLD_RED << "[!] Pilihan format tidak valid, dibatalkan.\n\n" << RESET;
        return;
    }

    string defaultFileName = promptFileNameValidated("Masukkan nama file laporan (Tanpa ekstensi) >> ", 30);
    string finalFileName;
    ofstream exportFile;

    if (exportChoice == 1) {
        finalFileName = defaultFileName + ".txt";
        exportFile.open(finalFileName);
        
        exportFile << "========================================================================\n";
        exportFile << "                       LAPORAN ABSENSI SEKOLAH                          \n";
        exportFile << "========================================================================\n";
        exportFile << "TANGGAL         | MINGGU | ID SISWA | NAMA SISWA           | STATUS     \n";
        exportFile << "------------------------------------------------------------------------\n";

        for (const auto& rec : attendanceList) {
            exportFile << left << setw(15) << rec.date
                       << " | " << left << setw(6) << rec.week
                       << " | " << left << setw(8) << rec.studentId
                       << " | " << left << setw(20) << rec.studentName
                       << " | " << rec.status << "\n";
        }
        exportFile << "========================================================================\n";
    } else if (exportChoice == 2) {
        clearScreen();
        cout << BOLD_CYAN << "\n      :: PENGATURAN REGIONAL EXCEL ::\n";
        cout << "-----------------------------------------\n" << RESET;
        cout << "Agar tabel tidak berantakan, sesuaikan dengan Excel Anda:\n";
        cout << "  " << BOLD_CYAN << "[1]" << RESET << " Pemisah Koma (,)       -> Excel Internasional\n";
        cout << "  " << BOLD_CYAN << "[2]" << RESET << " Pemisah Titik Koma (;) -> Excel Indonesia/Eropa\n\n";
        
        int sepChoice = promptInt("Pilihan >> ");
        
        char separator = ','; // Default internasional
        if (sepChoice == 2) {
            separator = ';';
        }

        finalFileName = defaultFileName + ".csv";
        exportFile.open(finalFileName);
        
        // Header CSV
        exportFile << "Tanggal" << separator 
                   << "Minggu Ke-" << separator 
                   << "ID Siswa" << separator 
                   << "Nama Siswa" << separator 
                   << "Status Kehadiran\n";
        
        for (const auto& rec : attendanceList) {
            exportFile << rec.date << separator
                       << rec.week << separator
                       << rec.studentId << separator
                       << rec.studentName << separator
                       << rec.status << "\n";
        }
    }

    exportFile.close();

    clearScreen();
    cout << BOLD_GREEN << "\n[v] Laporan Berhasil Diekspor!\n" << RESET;
    cout << "Silakan cek folder program Anda, file telah disimpan sebagai: " 
         << BOLD_CYAN << finalFileName << RESET << "\n\n";
}