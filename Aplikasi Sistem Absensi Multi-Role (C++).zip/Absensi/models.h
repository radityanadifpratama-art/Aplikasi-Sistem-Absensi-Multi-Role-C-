#pragma once
#include <iomanip>
#include <sstream>
#include <string>
using namespace std;

class User {
 public:
  string id;
  string name;
  string password;
  string role;
  string phone;

  // Default Constructor
  User() {}
  // Parameterized Constructor (Member Initializer List)
  User(string _id, string _name, string _pass, string _role, string _phone)
      : id(_id), name(_name), password(_pass), role(_role), phone(_phone) {}

  // Format output untuk file .txt
  // Ready-only
  string formatRecord() const {
        string safeName = name;
        for (char& c : safeName) {
            if (c == ' ') c = '_'; 
        }
        return id + " " + safeName + " " + password + " " + role + " " + phone;
    }
};

class AttendanceRecord {
 public:
  string date;
  string week;
  string studentId;
  string studentName;
  string status;

  AttendanceRecord() {}
  AttendanceRecord(string _date, string _week, string _id, string _name, string _status)
      : date(_date), week(_week), studentId(_id), studentName(_name), status(_status) {}

  string formatRecord() const {
        string safeName = studentName;
        for (char& c : safeName) {
            if (c == ' ') c = '_';
        }
        return date + " " + week + " " + studentId + " " + safeName + " " + status;
    }
};